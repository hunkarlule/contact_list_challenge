import java.util.Scanner;

public class Driver {
	public static void main(String[] args) {
		ContactList myContactList = new ContactList();
		myContactList.addContact("anil", "java", "abc@xzy.com", "555555555");
		myContactList.addContact("hunkar", "java", "qwe@xzy.com", "555555555");
		myContactList.addContact("rodrigo", "teacher", "rod@xzy.com", "555555555");

		// myContactList.listContacts();

		// myContactList.removeContact(2);
		//
		// myContactList.listContacts();
		showMenu();
		// myContactList.listContacts();

	}

	public static void showMenu() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("******************");
		String menu = "Contact Menu\n" + "1. Add\n" + "2. Remove\n" + "3.Search\n" + "4.List\n" + "5.Update\n"
				+ "0. Exit";
		System.out.println(menu);
		System.out.println("******************");

		int chosen = 999;
		while (chosen != 0) {

			System.out.print("Choose: ");
			chosen = scanner.nextInt();
			scanner.nextLine();

			switch (chosen) {
			case 1:
				System.out.println("enter first name:");
				String firstName = scanner.nextLine();

				System.out.println("enter last name:");
				String lastName = scanner.nextLine();

				System.out.println("enter email:");
				String email = scanner.nextLine();

				System.out.println("enter phone number:");
				String phoneNumber = scanner.nextLine();

				ContactList.addContact(firstName, lastName, email, phoneNumber);
				break;
			case 2:
				System.out.println("enter number of contact to remove:");
				int contactNo = scanner.nextInt();
				ContactList.removeContact(contactNo);
				break;
			case 3:
				System.out.println("enter name or surname to search");
				String searchText = scanner.nextLine();
				ContactList.searchContacts(searchText);
				break;
			case 4:
				ContactList.listContacts();
				break;

			case 5:
				ContactList.listContacts();
				System.out.println("enter contact number to update:");
				int contactNumber = scanner.nextInt();
				scanner.nextLine();
				String newFirstName;
				String newLastName;
				String newEmail;
				String newPhoneNumber;

				System.out.println("do you want to update firstName(Y/N):");
				String answer = scanner.nextLine();
				if (answer.equals("Y")) {
					System.out.println("enter new first name:");
					newFirstName = scanner.nextLine();
				} else {
					newFirstName = ContactList.contactList.get(contactNumber - 1).firstName;
				}

				System.out.println("do you want to update lastName(Y/N):");
				answer = scanner.nextLine();
				if (answer.equals("Y")) {
					System.out.println("enter new last name:");
					newLastName = scanner.nextLine();
				} else {
					newLastName = ContactList.contactList.get(contactNumber - 1).lastName;
				}

				System.out.println("do you want to update email(Y/N):");
				answer = scanner.nextLine();
				if (answer.equals("Y")) {
					System.out.println("enter new email:");
					newEmail = scanner.nextLine();
				} else {
					newEmail = ContactList.contactList.get(contactNumber - 1).email;
				}

				System.out.println("do you want to update phone number(Y/N):");
				answer = scanner.nextLine();
				if (answer.equals("Y")) {
					System.out.println("enter new phone number:");
					newPhoneNumber = scanner.nextLine();
				} else {
					newPhoneNumber = ContactList.contactList.get(contactNumber - 1).phoneNumber;
				}

				ContactList.removeContact(contactNumber);
				ContactList.addContact(newFirstName, newLastName, newEmail, newPhoneNumber);
				break;

			}
			if (chosen == 1 || chosen == 2)
				ContactList.listContacts();
		}
	}
}
