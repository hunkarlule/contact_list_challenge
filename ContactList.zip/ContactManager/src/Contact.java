
public class Contact {
 public String firstName;
 public String lastName;
 public String email;
 public String phoneNumber;
/**
 * @param firstName
 * @param lastName
 * @param email
 * @param phoneNumber
 */
public Contact(String firstName, String lastName, String email, String phoneNumber) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.phoneNumber = phoneNumber;
}
 
 
 
}
