import java.util.ArrayList;

public class ContactList {
	public static ArrayList<Contact> contactList;

	public ContactList() {
		contactList = new ArrayList<Contact>();
	}

	public static void addContact(String firstName, String lastName, String email, String phoneNumber) {
		contactList.add(new Contact(firstName, lastName, email, phoneNumber));
	}

	public static void removeContact(int contactNo) {
		contactList.remove(contactNo - 1);
	}

	public static void listContacts() {
		System.out.printf("%-5s%-20s%-20s%-20s%-20s\n", "no", "firstName", "lastName", "email", "phoneNumber");
		for (Contact myContacts : contactList) {
			System.out.printf("%-5d%-20s%-20s%-20s%-20s\n", contactList.indexOf(myContacts) + 1, myContacts.firstName,
					myContacts.lastName, myContacts.email, myContacts.phoneNumber);
		}

	}

	public static void searchContacts(String searchText) {
		System.out.printf("%-5s%-20s%-20s%-20s%-20s\n", "no", "firstName", "lastName", "email", "phoneNumber");
		for (Contact myContacts : contactList) {
			if (myContacts.firstName.equalsIgnoreCase(searchText) || myContacts.lastName.equalsIgnoreCase(searchText))
				System.out.printf("%-5d%-20s%-20s%-20s%-20s\n", contactList.indexOf(myContacts) + 1,
						myContacts.firstName, myContacts.lastName, myContacts.email, myContacts.phoneNumber);
		}

	}

}
